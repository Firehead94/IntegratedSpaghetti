<?php include 'view/header.php'; ?>
<div id="content">
    <h2>Error</h2>
    <p><?php echo $error; ?></p>
</div>
<?php include 'view/footer.php'; ?>