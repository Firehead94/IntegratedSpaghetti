<div style="display: inline-block; text-align: center; transform: translate(8%, 50%); zoom: 2">
Your new balance is $<?php echo $_SESSION['balance'] ?>.00<br />
Thank you!<br />
<input type="button" value="View Invoices" onclick="location.href ='invoices'" />&nbsp;<input type="button" value="Close" onclick="window.close()" />
</div>